import React, { useState } from "react";

function App() {
  const [form, setForm] = useState({ email: "", description: "", files: [], view: "portfolio" });

  const handleFileChange = (e) => {
    setForm({ ...form, files: Array.from(e.target.files) });
  };

  const handleFormChange = (e) => {
    const { name, value } = e.target;
    setForm({ ...form, [name]: value });
  };

  const handleFormSubmit = (e) => {
    e.preventDefault();
    console.log("Formulário enviado:", form);
    alert("Orçamento enviado com sucesso!");
  };

  return (
    <div className="container">
      <h1>Fyre Tattoo</h1>
      <div className="tabs">
        <button onClick={() => setForm({ ...form, view: "portfolio" })}>Portfólio</button>
        <button onClick={() => setForm({ ...form, view: "artes" })}>Artes Disponíveis</button>
        <button onClick={() => setForm({ ...form, view: "orcamento" })}>Solicitar Orçamento</button>
      </div>

      {form.view === "portfolio" && (
        <div className="tab-content">
          <p>Confira os trabalhos no Instagram:</p>
          <iframe
            src="https://www.instagram.com/vicdangelo_ink/embed"
            width="100%"
            height="600"
            frameBorder="0"
            scrolling="no"
            title="Instagram Fyre Tattoo"
          ></iframe>
        </div>
      )}

      {form.view === "artes" && (
        <div className="tab-content">
          <p>Em breve você poderá ver aqui as artes disponíveis para flash tattoo!</p>
        </div>
      )}

      {form.view === "orcamento" && (
        <div className="tab-content">
          <form onSubmit={handleFormSubmit}>
            <input
              type="email"
              name="email"
              placeholder="Seu email"
              value={form.email}
              onChange={handleFormChange}
              required
            />
            <textarea
              name="description"
              placeholder="Descreva a tatuagem que deseja"
              rows={4}
              value={form.description}
              onChange={handleFormChange}
              required
            />
            <input type="file" multiple accept="image/*" onChange={handleFileChange} />
            <button type="submit">Enviar Orçamento</button>
          </form>
          <p className="info">Os orçamentos são enviados para: victoriadangelo1995@gmail.com</p>
        </div>
      )}
    </div>
  );
}

export default App;
